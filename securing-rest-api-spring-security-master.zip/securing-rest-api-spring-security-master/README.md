# securing-rest-api-spring-security

Sample Code showing how to secure a REST Api with Spring Boot and Spring Security.
