package com.it.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringJava4sController {

    @RequestMapping(value="/userlogin",method=RequestMethod.GET)
    public String userValidation() {
        return "User: Successfully logged in!";

    }

    @RequestMapping(value="/adminlogin",method=RequestMethod.GET)
    public String adminValidation() {
        return "Admin: Successfully logged in!";

    }

}//class