package com.it;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.it.controller","com.it.repository"})
public class SpringBootRestApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApp1Application.class, args);
	}
}
