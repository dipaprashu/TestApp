package com.it;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.it.client.UserRestClient;

@SpringBootApplication(scanBasePackages="com.it.client")
public class SpringBootRestApiClient1Application {

	public static void main(String[] args) {
		
		SpringApplication.run(SpringBootRestApiClient1Application.class, args);
		
		//UserRestClient.deleteAllUsers();
		//UserRestClient.getUser();
		//UserRestClient.createUser();
		//UserRestClient.updateUser();
		UserRestClient.deleteUser();
		UserRestClient.listAllUsers();
		
	}//main
	
}//class
